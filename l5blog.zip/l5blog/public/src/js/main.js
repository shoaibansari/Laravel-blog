
$("#comment").click(function () {
        $('.comment-box').css("display","block");
    });


//ajax like function
var postId = 0;
$('.like').on('click', function(event){

  event.preventDefault();
  postId = event.target.dataset['postid'];
  
   if(event.target.innerText =='Like')
   {
      isLike1=true;
   }
   else
   {
      isLike1=false;
   }

  var isLike = event.target.previousElementSibling == null;
 
  $.ajax({
  	method: 'POST',
  	url: urlLike,
  	data: { isLike: isLike, postId: postId,  _token: token}
  })

  //console.log(isLike);
  .done(function(){

  	if (isLike1) {
  		 event.target.innerText = 'Liked';
  	}
  	else{
  	 	event.target.innerText = 'Like';
  	}

  });

});

//ajax comment function
$(function () {

        $('#sendcomment').on('submit', function (e) {
          
          e.preventDefault();

          $.ajax({
            method: 'POST',
            url: urlcomment,
            data: { comment: $('#comt').val(), postId: postId, _token: token}
            
          })
           
          .done(function(data){
            //console.log(data);
             $('#newcomt').text(data['new_body']);

          });

        });

      });


// guest sign up  modal

$("#guest-like").click(function () {
    $('#guest-modal').modal();
});
