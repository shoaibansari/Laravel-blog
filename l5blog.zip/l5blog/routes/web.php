<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware' => ['web']], function() {
    Route::get('/home', [
	'uses' => 'MainController@index',
	'as'   => 'home'
   ]);

    // User Routes
    Route::get('/account',[
		'uses' => 'UserController@getRegistration',
	    'as' => 'account'
	   ]);

	Route::post('/signup',[
		'uses' => 'UserController@UserRegister',
	    'as' => 'signup'
	   ]);

	Route::post('/login',[
		'uses' => 'UserController@UserLogIn',
	    'as' => 'login'
	   ]);

	Route::get('/logout',[
		'uses' => 'UserController@getLogout',
	    'as' => 'logout'
	   ]);

	// Dashboard Route
	Route::get('/dashboard',[
		'uses' => 'DashboardController@getDashboard',
	    'as' => 'dashboard',
	   ]);
    
    // Create New Post Route
	Route::get('/dashboard/createpost',[
		'uses' => 'DashboardController@CreatePost',
	    'as' => 'createpost',
	   ]);
    
    // Edit Post Routes
    Route::get('/dashboard/editpost/{postId}',[
		'uses' => 'DashboardController@EditPost',
	    'as' => 'editpost',
	   ]);

    Route::post('/dashboard/post-edit',[
		'uses' => 'DashboardController@postEditPost',
	    'as' => 'post-edit',
	   ]);

    Route::post('/dashboard/postsave',[
		'uses' => 'DashboardController@postSavePost',
	    'as' => 'postsave',
	   ]);


    // Delete Post Route
    Route::get('/delete-post/{post_id}',[
		'uses' => 'DashboardController@getDeletePost',
	    'as' => 'post.delete',
	   ]);

	
    // Blog Post slug,Like,Comments Routes
    Route::get('/blog/{slug}',[
		'uses' => 'BlogController@getSingle',
	    'as' => 'blog.single',
	   ])->where('slug', '[\w\d\-\_]+');

    Route::post('/blog/like',[
		'uses' => 'BlogController@postLikePost',
	    'as' => 'like',
	   ]);

    Route::post('/blog/comment/{post_id}',[
		'uses' => 'BlogController@postComment',
	    'as' => 'comment',
	   ]);

    Route::get('/blog',[
        'uses' => 'BlogController@index',
        'as' => 'blog'
    ]);

    // Categories
    Route::resource('categories', 'CategoryController', ['except' => 'create']);

    // Tags
    Route::resource('tags', 'TagController', ['except' => 'create']);

    Route::post('user/authenticate',[
    	'uses' => 'GuestController@authenticate',
    	'as'   => 'authenticate'
    ]);

    //user store
    Route::resource('user','GuestController', ['except' => 'create']);

    

});



Route::get('blog/tag/{slug}', 'TagController@show', ['except' => 'create'])->where('slug', '[\w\d\-\_]+');

Route::get('blog/category/{slug}', 'CategoryController@show', ['except' => 'create'])->where('slug', '[\w\d\-\_]+');


//Like Route
Route::post('/blog/like',[
		'uses' => 'BlogController@postLikePost',
	    'as' => 'like',
	   ]);

//Comments Route
Route::post('/blog/comment/{post_id}',[
		'uses' => 'BlogController@postComment',
	    'as' => 'comment',
	   ]);

//Contact Route
Route::get('contact', 'PagesController@getContact')->name('contact');
Route::post('contact', 'PagesController@postContact');


Auth::routes();

// Route::get('/home', 'HomeController@index')->name('home');
