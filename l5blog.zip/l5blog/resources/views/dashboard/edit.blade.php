@extends('layouts.dashboard-master')

@section('title')
   Edit Post
@endsection

@section('content')
@include('includes.message-block')
   <div class="row newpostform">
  	<div class="col-lg-8 col-md-7 col-sm-6">
  	  <div class="well">
  		<form class="form-horizontal" action="{{ route('post-edit', ['postId' => $post->id]) }}" method="post" enctype="multipart/form-data" data-editPostId="{{ $post->id }}">
  			<fieldset>
  				<legend>Edit Post</legend>
                 

                <div class="form-group">
                    <label for="post-tiltle" class="col-lg-2 control-label">Post Title</label>
                    <div class="col-lg-10">
                      <input type="text" name="post_title" class="form-control input-sm" value="{{ $post->post_title }}">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-tiltle" class="col-lg-2 control-label">Post Slug</label>
                    <div class="col-lg-10">
                      <input type="text" name="slug" class="form-control input-sm" value="{{ $post->slug }}">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="category_id" class="col-lg-2 control-label">Post Category</label>
                    <div class="col-lg-10">
                      <select class="form-control input-sm" name="category">
                        <option></option>
                        @foreach($categories as $category)
                           <option value="{{ $category->id }}" {{ $post->category_id == $category->id ? "selected" : "" }}>{{ $category->name }}</option>
                        @endforeach
                      </select>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="tags" class="col-lg-2 control-label">Post Tags</label>
                    <div class="col-lg-10">
                      {{-- <select class="form-control select2-multi" name="tags[]" multiple="multiple">
                        <option></option>
                        @foreach($tags as $tag)
                           <option value="{{ $tag->id }}">{{ $tag->name }}</option>
                        @endforeach
                      </select> --}}
                      {{ Form::select('tags[]', $tags, null, ['class'=> 'form-control select2-multi', 'multiple' =>'multiple']) }}
                    </div>
                  </div>


                  <div class="form-group">
                    <label for="description_title" class="col-lg-2 control-label">Description</label>
                    <div class="col-lg-10">
                      <textarea class="form-control input-sm" name="description" rows="5">{{ $post->description }}</textarea>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-image" class="col-lg-2 control-label">Post Image</label>
                    <div class="col-lg-10">
                      <img src="{{ asset('public/images/'. $post->post_image) }}" name="post_image" class="img-thumbnail" width="250">
                       <br><br>
                      <input type="file" name="post_image">
                    </div>                
                  </div>
                  <br>
                  <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                      <button type="reset" class="btn btn-default">Cancel</button>
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </div>
                  
  			</fieldset>
  			<input type="hidden" name="_token" value="{{ Session::token() }}" >
  		</form>	
  	  </div>
  	</div>
  </div>


@endsection

@section('scripts')
   <script type="text/javascript">
     $('.select2-multi').select2();
     $('.select2-multi').select2().val({!! json_encode($post->tags()->allRelatedIds()) !!}).trigger('change');
   </script>
@endsection
