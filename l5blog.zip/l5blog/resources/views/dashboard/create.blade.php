@extends('layouts.dashboard-master')

@section('title')
   Create Post
@endsection

@section('content')
@include('includes.message-block')
  <div class="row newpostform">
  	<div class="col-lg-8 col-md-7 col-sm-6">
  	  <div class="well">
  		<form class="form-horizontal" action="{{ route('postsave') }}" method="post" enctype="multipart/form-data">
  			<fieldset>
  				<legend>Create New Post</legend>
                 

                <div class="form-group">
                    <label for="post-tiltle" class="col-lg-2 control-label">Post Title</label>
                    <div class="col-lg-10">
                      <input type="text" name="post_title" class="form-control" placeholder="Title" value="{{ Request::old('post_title') }}">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-slug" class="col-lg-2 control-label">Post Slug</label>
                    <div class="col-lg-10">
                      <input type="text" name="slug" class="form-control" placeholder="Slug" value="{{ Request::old('slug') }}">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="category_id" class="col-lg-2 control-label">Post Category</label>
                    <div class="col-lg-10">
                      <select class="form-control" name="category">
                        <option></option>
                        @foreach($categories as $category)
                           <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                      </select>
                    </div>
                  </div>


                  <div class="form-group">
                    <label for="tags" class="col-lg-2 control-label">Post Tags</label>
                    <div class="col-lg-10">
                      <select class="form-control select2-multi" name="tags[]" multiple="multiple">
                        <option></option>
                        @foreach($tags as $tag)
                           <option value="{{ $tag->id }}">{{ $tag->name }}</option>
                        @endforeach
                      </select>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post_description" class="col-lg-2 control-label">Description</label>
                    <div class="col-lg-10">
                      <textarea class="form-control" name="description" rows="5"></textarea>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-image" class="col-lg-2 control-label">Post Image</label>
                    <div class="col-lg-10">
                      <input type="file" name="post_image">
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                      <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                      <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                    </div>
                  </div>
                  
  			</fieldset>
  			<input type="hidden" name="_token" value="{{ Session::token() }}" >
  		</form>	
  	  </div>
  	</div>
  </div>
@endsection

@section('scripts')
   <script type="text/javascript">
     $('.select2-multi').select2();
   </script>
@endsection

