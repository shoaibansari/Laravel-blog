<nav class="navbar navbar-default">
         <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="{{ route('home') }}">LOGO</a>
          </div>
           <div id="navbar">
             <ul class="nav navbar-nav">
            	 {{-- <li><a href="">Home</a></li>
            	 <li><a href="">About</a></li> --}}
              <li><a href="{{ route('home') }}">Home</a></li>
              <li><a href="{{ route('blog') }}">Blog</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Contact Us</a></li>
             </ul>

             <ul class="nav navbar-nav navbar-right">

              @if(Auth::check())
               
               @if(Auth::user()->role_id === 1)
                 <li><a href="{{ route('dashboard') }}">Dashboard</a></li>
               @endif

              <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->fullname }}<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="{{ route('logout') }}">Logout</a></li>
                </ul>
              </li>
             

              @elseif (!Auth::check())
                  
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <form action="{{ route('login') }}" method="post" class="login-tab">
                    <li class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                      <label class="control-label sr-only" for="email">Email</label>
                      <input type="email" name="email" class="form-control input-sm" id="email" placeholder="Email">
                    </li>
                    <li class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                      <label class="control-label sr-only" for="password">password</label>
                      <input type="password" name="password" class="form-control input-sm" id="password" placeholder="Password">
                    </li>
                    <input type="hidden" name="role_id" value="1">
                    <button type="submit"  class="btn btn-primary btn-sm" >Login</button>
                     <a href="{{ route('account') }}" class="btn btn-link newuserlink">create account</a>

                     <input type="hidden" name="_token" value="{{ Session::token() }}">

                  </form>

                </ul>
              </li>

              @else

              @endif
                
              

            </ul>
          </div>
        </div>
      </nav>

