<nav class="navbar navbar-default">
         <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand {{ Request::is('dashboard') ? "active" : "" }}" href="{{ route('dashboard') }}">Dashboard</a>
          </div>
           <div id="navbar">
             <ul class="nav navbar-nav">
            	 {{-- <li><a href="">Home</a></li>
            	 <li><a href="">About</a></li> --}}
               
              <li><a href="{{ route('home') }}">Home</a></li>

              <li><a href="{{ route('createpost') }}">Create New Post</a></li>

              <li class="{{ Request::is('categories') ? "active" : "" }}"><a href="{{ route('categories.index') }}">Categories</a></li>
              <li class="{{ Request::is('tags') ? "active" : "" }}"><a href="{{ route('tags.index') }}">Tags</a></li>
             </ul>

             <ul class="nav navbar-nav navbar-right">
              {{-- <li><a href="{{ route('logout') }}">Logout</a></li> --}}
              <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">{{ Auth::user()->fullname }} <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="{{ route('logout') }}">Logout</a></li>
                  </ul>
              </li>

            </ul>
            
            

          </div>
        </div>
      </nav>


