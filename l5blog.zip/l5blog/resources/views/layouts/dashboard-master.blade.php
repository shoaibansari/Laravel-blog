<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, user-scalable=yes">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>@yield('title')</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="{{ URL::to('public/src/css/main.css') }}">
    <link rel="stylesheet" type="text/css" href="{{ URL::to('public/src/css/select2.min.css') }}">

</head>
<body>
     @include('includes.header-dashboard')
    <div class="container">
      @yield('content')
    </div>

    <!-- JavaScript Files here-->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-migrate/3.0.1/jquery-migrate.min.js"></script>
    
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

     <script type="text/javascript" src="{{ URL::to('public/src/js/main.js') }}"></script>
     <script type="text/javascript" src="{{ URL::to('public/src/js/select2.min.js') }}"></script>
     {{-- <script src="{{ URL::to('src/js/app.js') }}"></script> --}}
     @yield('scripts')
     
</body>
</html>
