@extends('layouts.master')

@section('title')
  Blog | Home !
@endsection

@section('content')
@include('includes.message-block')
<h1>Home</h1>

@endsection