@extends('layouts.dashboard-master')

@section('title')
  Blog | All Categories
@endsection

@section('content')
     @include('includes.message-block')
     <duiv class="row">
     	<div class="col-md-8">
     		<h2>Categories</h2>
     		<table class="table table-striped">
     			<thead>
     				<tr>
     					<th>#</th>
     				    <th>Name</th>
     				</tr>
     			</thead>
     			<tbody>
            <?php $i = 0; ?> 
     				@foreach($categories as $category)
	     				<tr>
	     					<th>{{ $i += 1 }}</th>
	     					<td>{{ $category->name }}</td>
	     				</tr>
     				@endforeach
     			</tbody>
     		</table>
     	</div> {{-- end of .col-md-8 --}}
        
        <div class="col-md-3" style="margin-top: 30px;">
          <div class="well">
          	<h4>New Category</h4>
           	<form method="post" action="{{ route('categories.store') }}">
           	   <div class="form-group">
           	   	 <label>Name</label>
           	   	 <input type="text" name="name" class="form-control input-sm">  
           	   </div>

           	   <div class="form-group">
                 <button type="submit" class="btn btn-primary btn-block btn-xs">Create New Category</button>
               </div>
           	   <input type="hidden" name="_token" value="{{ Session::token() }}">  
           	</form>
          </div>
        </div>

     </duiv>

@endsection