@extends('layouts.master')

@section('title')
    Blog | Blog !
@endsection

@section('content')
    @include('includes.message-block')
    <h1>Blog</h1>
    <hr>
    <div class="row">

        {{--Post--}}
        <div class="col-lg-9" style="padding-bottom: 83px;">

            @foreach($posts as $post)

                <h3 style="text-transform: capitalize;font-weight: 100;font-size: medium;">{{ $post->post_title }}</h3>

                <div class="row">
                    <div class="col-md-4">
                        <a href="{{ url('blog/'.$post->slug) }}">
                            <img class="post-thumb" src="{{ asset('/public/images/'. $post->post_image) }}" alt="{{ $post->post_title }}">
                        </a>
                    </div><!-- col-md-3 -->

                    <div class="col-md-8" style="padding-left: 0;">
                        <small class="post-date" style="margin: 0 0 10px;">Posted on: {{ date('M-j-Y',strtotime($post->created_at)) }} | Category: <strong>{{ $post->category->name }}</strong></small>
                           <p style="margin: 0 0 5px;">{{ str_limit($post->description, 200) }}</p>

                        <div class="row">
                            <div class="col text-center small p-2">
                                <p style="float: left;padding-left: 15px;">
                                    @if(count($post->comments) > 0)
                                        <a><i class="fa fa-comment"></i> {{ $post->comments()->count() }}</a>
                                    @endif
                                    @if(count($post->likes) > 0)
                                       |  <a><i class="fa fa-thumbs-up"></i> {{ $post->likes()->count() }}<a>
                                    @endif
                                </p>
                            </div>
                        </div>
                        <p><a class="btn btn-default btn-sm" href="{{ url('blog/'.$post->slug) }}">Read More</a></p>

                    </div><!-- col-md-9 -->

                </div><!-- row -->

            @endforeach

                <div class="row">
                    <div style="text-align: center;">
                        {{$posts->links()}}
                    </div>
                </div>
        </div>

        {{--Sidebar Search, Categories, Tags--}}
        <div class="col-md-3" style="margin-top: 30px;">

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Search</h3>
                </div>
                <div class="panel-body">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
                    </div>
                </div>
            </div>

            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Categories</h3>
                </div>
                <div class="panel-body">

                   @foreach($categories as $category)
                        @if(count( $category->posts ) > 0)
                            <a href="{{ url('blog/category/'.$category->slug)}}" class="btn btn-default btn-xs">{{$category->name}}</a>
                        @endif
                   @endforeach

                </div>
            </div>

            {{--@if(count($post->tags) > 0)--}}

                <div class="panel panel-warning">
                    <div class="panel-heading">
                        <h3 class="panel-title">Tags</h3>
                    </div>
                    <div class="panel-body">
                        @foreach($tags as $tag)
                           @if(count($tag->posts ) > 0)
                              <a href="{{ url('blog/tag/'.$tag->slug)}}" class="label label-default">{{$tag->name}}</a>
                           @endif
                        @endforeach
                    </div>
                </div>

            {{--@elseif (!count($post->tags))--}}
                {{--<div></div>--}}
            {{--@else--}}

            {{--@endif--}}


        </div> {{--colg-md-3--}}

    </div> {{--row--}}

@endsection