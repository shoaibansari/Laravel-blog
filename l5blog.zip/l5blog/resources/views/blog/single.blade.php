@extends('layouts.master')

@section('title')
  Blog | {{ $post->post_title }}
@endsection

@section('content')
 
  <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8" style="padding-bottom: 83px;">

          <!-- Title -->
          <h1 class="mt-4" style="text-transform: capitalize;">{{ $post->post_title }}</h1>

          <hr>

          <!-- Date/Time -->
          <p class="comment-time">Posted on {{ date('M j D, Y - g:i A',strtotime($post->created_at)) }} by <a href="#">{{ $post->user->fullname }}</a></p>

          <hr>

          <!-- Preview Image -->
          <img class="img-fluid rounded" src="{{ asset('/public/images/'. $post->post_image) }}" alt="{{ $post->post_title }}">

          <hr>

          <!-- Post Content -->
          <p class="lead" style="padding-left: 0px;">{{ $post->description }}</p>

          <hr>
          
          <div>
            {{-- <a href="#" class="like" data-postid="{{ $post->id }}">{{ Auth::user()->likes()->where('post_id', $post->id)->first() ? Auth::user()->likes()->where('post_id', $post->id)->first()->like == 1 ? 'Liked' : 'Liked' : 'Like' }}</a> | <a href="#" id="comment">Comment</a> --}} 
            @if(Auth::check())
               
               <a href="#" class="like" data-postid="{{ $post->id }}">{{ Auth::user()->likes()->where('post_id', $post->id)->first() ? Auth::user()->likes()->where('post_id', $post->id)->first()->like == 1 ? 'Liked' : 'Like' : 'Like' }}</a> | <a href="#" id="comment">Comment</a>

              @elseif(Auth::guest() > 0)
                
                 <a href="#" id="guest-like" style="padding-right: 0px !important;">Like</a>
                @if(count($post->likes))
                  <small style="color: #777;font-size: 10px;">{{ $post->likes()->count() }}</small>
                @endif
               | <a href="#" id="comment">Comment</a>               
              @else

            @endif
            

            @if(count($post->comments) > 0)
             <h6 style="float: right;font-weight: 100;color: #777;">Comments <small>{{ $post->comments()->count() }} total</small></h6> 
            @endif
            

          </div>
          <div id="postRequestData"></div>
          <!-- Comments Form -->
          <div class="comment-box">
            
          <div class="card my-4">
            <h5 class="card-header">Leave a Comment:</h5>
            <div class="card-body">
              <form id="sendcomment" method="post">
                <div class="form-group">
                  <textarea class="form-control" id="comt" name="comment"  rows="3" style="resize: none;"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
             
            @foreach($post->comments as $comment)

            <!-- Single Comment -->
            <div class="comment-area" >
              <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
              <div class="media-body">
                <h5 class="mt-0" style="text-transform: capitalize;">{{ $comment->user->fullname }}</h5>
                {{-- {{ $comment->comment }} --}}
                <p id="newcomt">{{ $comment->comment }}</p>
              </div>
            </div>

           @endforeach

          </div><!-- comment-box -->
          
          
        </div>

       <div class="col-md-4" style="margin-top: 30px;">

            <div class="panel panel-primary">
              <div class="panel-heading">
			    <h3 class="panel-title">Search</h3>
			  </div>
			  <div class="panel-body">
			    <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
              </div>
			  </div>
		    </div>

			<div class="panel panel-success">
			  <div class="panel-heading">
			    <h3 class="panel-title">Post Category</h3>
			  </div>
			  <div class="panel-body">
         {!! $cats !!}
			  </div>
			</div>

     @if(count($post->tags) > 0)

  			<div class="panel panel-warning">
  			  <div class="panel-heading">
  			    <h3 class="panel-title">Post Tag</h3>
  			  </div>
  			  <div class="panel-body">
  			    {!! implode(' ',$tags) !!}
  			  </div>
  			</div>

        @elseif (!count($post->tags)) 
          <div></div>
        @else

      @endif

    

        </div>

  </div>
  
  @include('blog.guest-login-modal')


   <script>
     var token = '{{ Session::token() }}';
     var urlLike = '{{ route('like') }}';
     var urlcomment = '{{ route('comment', ['postId' => $post->id]) }}';
  </script>
@endsection