<!--Guest login modal -->
  <div class="modal fade bs-example-modal-sm" id="guest-modal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Login/Signup</h4>
      </div>
      <ul class="nav nav-tabs">
        <li class="active" style="padding-left: 15px;"><a href="#Login" data-toggle="tab">Login</a></li>
        <li><a href="#Registration" data-toggle="tab">Registration</a></li>
      </ul>
      <div class="modal-body">
        <div class="tab-content">
          
          <form action="{{ route('authenticate') }}" method="post" class="signup-form tab-pane active" id="Login">
            
            <li class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
              <label class="control-label sr-only" for="email">Email</label>
              <input type="email" name="email" class="form-control input-sm" id="email" placeholder="Email">
            </li>
            <li class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
              <label class="control-label sr-only" for="password">password</label>
            <input type="password" name="password" class="form-control input-sm" id="password" placeholder="Password">
            </li>
            <input type="hidden" name="role_id" value="2">
            <button type="submit" class="btn btn-primary btn-sm signup-btn">Login</button>
             
            <input type="hidden" name="_token" value="{{ Session::token() }}">

          </form>

          <form action="{{ route('user.store') }}" method="post" class="signup-form tab-pane" id="Registration">
            <li class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
              <label class="control-label sr-only" for="email">Name</label>
              <input type="text" name="fullname" class="form-control input-sm" placeholder="Name" value="{{ Request::old('fullname') }}">
            </li>
            <li class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
              <label class="control-label sr-only" for="email">Email</label>
              <input type="email" name="email" class="form-control input-sm" id="email" placeholder="Email"
              value="{{ Request::old('email') }}">
            </li>
            <li class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
              <label class="control-label sr-only" for="password">password</label>
            <input type="password" name="password" class="form-control input-sm" id="password" placeholder="Password" value="{{ Request::old('password') }}">
            </li>
            <input type="hidden" name="role_id" value="2">
            <button type="submit" class="btn btn-primary btn-sm signup-btn">Create a Account</button>
            {{-- <a href="{{ route('account') }}" class="btn btn-link newuserlink">create account</a> --}}

            <input type="hidden" name="_token" value="{{ Session::token() }}">
          </form>


        </div><!-- tab-content -->

      </div>
      
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->