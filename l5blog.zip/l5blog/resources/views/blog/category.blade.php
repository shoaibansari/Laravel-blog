@extends('layouts.master')

@section('title')
  Blog | {{ $cat->name }}
@endsection

@section('content')
   {{-- {{ $cat->name }} --}}
   <div class="row">
   	  <h2 class="mt-4">{{ $cat->name }} <small>{{ $cat->posts()->count() }} Posts</small></h2>
   	  <hr>

   	  @foreach($cat->posts as $cpost)
   	     
   	  <div class="col-sm-6 contpost">
        <div class="row">
          <div class="col PostTitle">
             <h4 style="text-transform: capitalize;"><a href="{{ url('blog/'.$cpost->slug) }}">{{ $cpost->post_title }}</a></h4>
            <div class="PostDate"><i class="fa fa-calendar"></i>
              {{ date('M j, Y',strtotime($cpost->created_at)) }}</div>

          </div>
        </div>
    <div class="row">
      <div class="col-sm-6 feature-img">
        <a href="{{ url('blog/'.$cpost->slug) }}" class="img-responsive">
            <img src="{{ asset('/public/images/'. $cpost->post_image) }}" alt="{{ $cpost->post_title }}" width="260" height="180">
        </a>
      </div>
      <div class="col-sm-6" style="padding-left: 0;">      
        <p>
          {{ str_limit($cpost->description, 100) }}
        </p>
        <p><a class="btn btn-sm btn-success" href="{{ url('blog/'.$cpost->slug) }}">Read More</a></p>
      </div>
    </div>
    <div class="row">
      <div class="col text-center small p-2">
        <p style="float: left;padding-left: 15px;">
          <i class="fa fa-user-circle"></i> by <a href="#">{{ $cpost->user->fullname }}</a> 
        
          @if(count($cpost->comments) > 0)

          | <a><i class="fa fa-comment"></i> {{ $cpost->comments()->count() }}</a>
              
          @endif

          @if(count($cpost->likes) > 0)

           | <a><i class="fa fa-thumbs-up"></i> {{ $cpost->likes()->count() }}<a>

          @endif

          
          | <i class="fa fa-tag"></i> Category : 
          
          <a href="{{ url('blog/category/'.$cpost->category->slug) }}" class="label label-default">{{ $cpost->category->name }}</a>
          
        </p>
      </div>
    </div> 
   </div>{{-- col-sm-6 --}}

   @endforeach

       <div style="text-align: center;">
           {{--{{$posts->links()}}--}}
       </div>
  </div>{{-- end row --}}

@endsection