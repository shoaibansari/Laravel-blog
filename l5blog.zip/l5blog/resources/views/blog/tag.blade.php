@extends('layouts.master')

@section('title')
  Blog | {{ $tag->name }}
@endsection

@section('content')
   
   <div class="row">
   	  <h2 class="mt-4">{{ $tag->name }} <small>{{ $tag->posts()->count() }} Posts</small></h2>
   	  <hr>

   	  @foreach($tag->posts as $tpost)
   	     
   	  <div class="col-sm-6 contpost">
    <div class="row">
      <div class="col PostTitle">
        <h4 style="text-transform: capitalize;"><a href="{{ url('blog/'.$tpost->slug) }}">{{ $tpost->post_title }}</a></h4>
        <div class="PostDate"><i class="fa fa-calendar"></i> 
          {{ date('M j, Y',strtotime($tpost->created_at)) }}</div>

      </div>
    </div>
    
    <div class="row">
      <div class="col-sm-6 feature-img">
        <a href="{{ url('blog/'.$tpost->slug) }}" class="img-responsive">
            <img src="{{ asset('/public/images/'. $tpost->post_image) }}" alt="{{ $tpost->post_title }}" width="260" height="180">
        </a>
      </div>
      <div class="col-sm-6" style="padding-left: 0;">      
        <p>
          {{ str_limit($tpost->description, 100) }}
        </p>
        <p><a class="btn btn-sm btn-success" href="{{ url('blog/'.$tpost->slug) }}">Read More</a></p>
      </div>
    </div>
    <div class="row">
      <div class="col text-center small p-2">
        <p style="float: left;padding-left: 15px;">
          <i class="fa fa-user-circle" style="color: #777;"></i> by <a href="#">{{ $tpost->user->fullname }}</a> 
        
          @if(count($tpost->comments) > 0)

          | <a><i class="fa fa-comment"></i> {{$tpost->comments()->count()}}<a>
              
          @endif

          @if(count($tpost->likes) > 0)

           | <a><i class="fa fa-thumbs-up"></i> {{ $tpost->likes()->count() }}<a>

          @endif

          | <i class="fa fa-tags" style="color: #777;"></i> Tags : @foreach ($tpost->tags as $tag)<a href="{{ url('blog/tag/'.$tag->slug) }}" class="label label-default" >{{ $tag->name }}</a>
            @endforeach  
     
        </p>
      </div>
    </div> 
   </div>{{-- col-sm-6 --}}

   @endforeach

  </div>{{-- end row --}}

@endsection
