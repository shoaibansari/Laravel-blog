@extends('layouts.dashboard-master')

@section('title')
   Admin dashboard
@endsection

@section('content')
@include('includes.message-block')
  <h1>Dashboard</h1>
  <h6>Hello {{ Auth::user()->fullname }} !! 
  	@if(Auth::user()->role_id == 1) (Admin)
  	@endif
  	@if(Auth::user()->role_id == 2) (User)
  	@endif
  </h6>

  {{ date('j D M  Y -  g:i A',time()) }}
<div class="row newpostform">
	     
	     @foreach($posts as $post)

         @if(Auth::user() == $post->user)  
	      
         <div class="col-lg-4 col-md-7 col-sm-6" data-postid="{{ $post->id }}">
	    <div class="panel panel-default">
		  	<a href="{{ url('blog/'.$post->slug) }}"><img src="{{ asset('public/images/'. $post->post_image) }}" class="img-responsive"></a>
		  	<div class="panel-body">
		  	  <ul>
		  		<li><a href="{{ url('blog/'.$post->slug) }}" class="btn btn-info btn-xs">Preview</a></li>
		  		<li><a href="{{ route('editpost', ['postId' => $post->id]) }}" class="btn btn-default btn-xs">Edit</a></li>
		  		<li><a href="{{ route('post.delete', ['post_id' => $post->id]) }}" class="btn btn-danger btn-xs">Delete</a></li>
		  	  </ul>
		  	</div>
			<div class="panel-heading">{{ $post->post_title }}</div>
			<div class="panel-body">{{ str_limit($post->description, 70)}}</div>
		  </div>  
    </div>
    @endif

    @endforeach

    
    

	
  	
   
</div>

@endsection