@extends('layouts.master')

@section('title')
  User Register !
@endsection

@section('content')
 @include('includes.message-block')
<div class="row user-registerfrom">
   	  <div class="col-md-12">
   	  	 <h3 class="signup-heading">Sign Up</h3>
                    <form action="{{ route('signup') }}" method="post" class="form-horizontal" >

                      <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                        <label for="name" class="col-md-4 control-label">Email</label>
                         <div class="col-md-6">
                            <input type="email" name="email" class="form-control" id="email" value="{{ Request::old('email') }}">
                         </div>
                        </div>

                        <div class="form-group{{ $errors->has('fullname') ? ' has-error' : '' }}">
                          <label for="email" class="col-md-4 control-label">Full Name</label>
                           <div class="col-md-6">
                              <input type="text" name="fullname" class="form-control" id="fullname" value="{{ Request::old('fullname') }}">
                           </div>
                        </div>

                       <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                        <label for="password" class="col-md-4 control-label">Password</label>
                         <div class="col-md-6">
                           <input type="password" name="password" class="form-control" id="password" value="{{ Request::old('password') }}">
                         </div>
                       </div>
                        <input type="hidden" name="role_id" value="1">
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                        <input type="hidden" name="_token" value="{{ Session::token() }}">
                    </form>
                </div>
            </div>

@endsection