<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class PagesController extends Controller
{
    public function getContact()
    {
        //load contact page
        return view('pages.contact');
    }

    /**
     * @param Request $request
     */
    public function postContact(Request $request)
    {
        //send email from here
        $this->validate($request, [
            'email'    => 'required|email',
            'subject' =>  'min:3',
            'message' =>  'min:10'
        ]);

        $data = array(
            'email' => $request->email,
            'subject' => $request->subject,
            'bodyMessage' => $request->message
        );

        Mail::send('emails.contact', $data, function($message) use ($data){
                    $message->from($data['email']);
                    $message->to('shoaib-004e7a@inbox.mailtrap.io');
                    $message->subject($data['subject']);
             });

        $message = 'Your email has been send';

        //return redirect('/contacts')->with(['msg' => $msg]);
        return redirect()->route('contact')->with(['message' => $message]);
    }
}
