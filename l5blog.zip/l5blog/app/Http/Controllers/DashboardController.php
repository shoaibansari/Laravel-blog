<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use App\Category;
use App\Tag;
use Image;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;


class DashboardController extends Controller
{
    public function getDashboard()
    {
        if(!Auth::user()){
            return redirect()->route('home');
        }else{
            $posts = Post::orderBy('created_at', 'desc')->get();
            if(Auth::user()->role_id === 1){
               return view('dashboard', ['posts' => $posts]);
            }
        } 	    
    }

    public function CreatePost()
    {   
    	if(!Auth::user()){
        	return redirect()->route('home');
        }
        $categories = Category::all();
        $tags = Tag::all();
    	return view('dashboard.create')->withCategories($categories)->withTags($tags);
    }

    public function postSavePost(Request $request)
    { 

    	$this->validate($request, [
            'post_title'  => 'required|max:100',
            'description' => 'required|max:1000',
            'slug'        => 'required|alpha_dash|min:5|max:255',
            'category'    => 'required|integer',
            'post_image'  => 'required'
        ]);
      
    	$post = new post();
    	$post->post_title  = $request['post_title'];
    	$post->description = $request['description'];
        $post->category_id = $request['category'];
    	$post->slug        = $request['slug'];
        $post->created_at  = new DateTime();
        $post->updated_at  = new DateTime();
        // $now = new DateTime();
    	$message           = 'There was an error';
        
    	//$post->post_image = $request['post_image'];
        
        //save our image
        if($request->hasFile('post_image')){
        	$image = $request->file('post_image');
        	$filename = time() . '.' . $image->getClientOriginalExtension();
        	$location = public_path('images/'. $filename);
        	image::make($image)->resize(800, 400)->save($location);
          
            $post->post_image = $filename;
        }


        if($request->user()->posts()->save($post))
        {
            $post->tags()->sync($request['tags'], false);
            // $post->tags()->attach($request['tags']);
        	$message = 'Post Succcessfully created!';
        }
         return redirect()->back()->with(['message'=> $message]);
    }


    public function getDeletePost($post_id)
    {
        $post = Post::where('id', $post_id)->first();
        //$post = tag::where('post_id', $post_id)->first();
        $post->tags()->detach();
        if(Auth::user() != $post->user){
        	return redirect()->route('home');
        }
        $post->delete();
        return redirect()->route('dashboard')->with(['message'=> 'Succcessfully deleted']);
    }

    public function EditPost(Request $request)
    {   
        //select post from id
        $post       = Post::find($request['postId']);

        //select all category 
        $categories = Category::all();

        //fetch all tags in array 
        $tags       = Tag::all(); 
        $tags2 = array();
        foreach ($tags as $tag){
            $tags2[$tag->id] = $tag->name;
        }

        return view('dashboard.edit')->withPost($post)->withCategories($categories)->withTags($tags2);
    }

    public function postEditPost(Request $request)
    {    

         $this->validate($request, [
            'post_title'  => 'required|max:100',
            'description' => 'required|max:1000',
            'slug'        => 'required|alpha_dash|min:5|max:255',
            'category' => 'required|integer'
        ]);

        //Save the data to the database
        $post = Post::find($request['postId']);

        $post->post_title  = $request['post_title'];
        $post->description = $request['description'];
        $post->slug        = $request['slug'];
        $post->category_id = $request['category'];
        $post->updated_at  = now();

        if($request->hasFile('post_image')){
            $image = $request->file('post_image');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('images/'. $filename);
            image::make($image)->resize(800, 400)->save($location);
          
            $post->post_image = $filename;
        }
        if($post->update()){
            $post->tags()->sync($request['tags']);
            $message = 'Post Succcessfully Updated!';
        }
        return redirect()->route('dashboard')->with(['message'=> $message]);
    }

}
