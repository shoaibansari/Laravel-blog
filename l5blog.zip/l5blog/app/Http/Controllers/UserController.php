<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class UserController extends Controller
{
    public function getRegistration()
    {
        return view('register');
    }

	 public function UserRegister(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email|unique:users',
            'fullname' => 'required|max:20',
            'password' => 'required|min:4'
        ]);
        $email = $request['email'];
        $fullname = $request['fullname'];
        $password = bcrypt($request['password']);
        $role_id  = $request['role_id'];

        $user = new User();
        $user->email    = $email;
        $user->fullname = $fullname;
        $user->password = $password;
        $user->role_id  = $role_id;

        $user->save();

        Auth::login($user);

        return redirect()->route('dashboard');
    }

	public function UserLogIn(Request $request)
	{  
        $this->validate($request, [
             'email'      => 'required',
             'password'   => 'required'
        ]);

        if(Auth::attempt(['email' => $request['email'], 'password' => $request[
         'password'], 'role_id' => $request['role_id']])){
            
            return redirect()->route('dashboard');
        }

        return redirect()->back();
	}

    public function getLogout()
    {
        Auth::logout();
        return redirect()->route('home');
    }

    
}
