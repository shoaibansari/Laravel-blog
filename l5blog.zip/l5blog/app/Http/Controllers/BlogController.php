<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Post;
use App\Like;
use App\User;
use App\Comment;
use App\Tag;
use App\Category;


class BlogController extends Controller
{
    public function index()
    {
        $categories = Category::all();
        $tags = Tag::all();
        $posts = Post::orderBy('created_at', 'desc')->paginate(1);
        return view('blog.index')->withPosts($posts)->withCategories($categories)->withTags($tags);

    }
    public function getSingle($slug)
    {
        //fetch from the DB base on slug
        $post = Post::where('slug', '=', $slug)->first();
        
        //post tags fetch data from database with link 
        if(count($post) > 0){ 

        if(count($post->tags) > 0){
           foreach($post->tags as $tag){
            $tags[] = link_to('blog/tag/'.$tag->slug, $tag->name, ['class="label label-default"']);}
           }else{$tags[] = '';}

        }else{
                return abort(404);
        }
        
        //post categories fetch from database with link
        if(count($post->category) > 0){
            $cat  = $post->category;
            $cats = link_to('blog/category/'.$cat->slug, $cat->name, ['class="btn btn-default btn-xs"']);
          }else{
            $cats = '';
        }

        //check post slug
    		if(count($post) > 0){       
          //return the view and pass in the post object
    			return view('blog.single')->withPost($post)->withTags($tags)->withCats($cats);
    		}else{
    			return abort(404);
    		}
        
    }

    public function postLikePost(Request $request)
    {
         $post_id = $request['postId'];
         $is_like = $request['isLike'] === 'true';
         $update = false;
         $post = Post::find($post_id);
         if(!$post){
           return null;
         }
         $user = Auth::user();
         $like = $user->likes()->where('post_id', $post_id)->first();
         
         if($like) {
        $already_like = $like->like;
        $update = true;
        if($already_like == $is_like) {
          $like->delete();
          return null;
        }        
	    }else {
	         $like = new Like();
	      }
	      $like->like = $is_like;
	      $like->user_id = $user->id;
	      $like->post_id = $post->id;
	      if($update) {
	        $like->update();
	      }else {
	         $like->save();
	      }
	      return null;
    }

    public function postComment(Request $request)
    {   
        //find ID for comment on post
        $comment = Post::find($request['post_id']);
        
        //create new comment & save in database
        $comment = new Comment();
        $comment->comment = $request['comment'];
        $comment->post_id = $request['post_id'];
        $request->user()->comments()->save($comment);
		
        return Response::json( ['new_body'=> $comment->comment], 200 );
    }
}
