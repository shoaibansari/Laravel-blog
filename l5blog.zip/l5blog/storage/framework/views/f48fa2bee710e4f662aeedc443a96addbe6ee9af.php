<nav class="navbar-inverse">
         <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
          </div>
           <div id="navbar">
             <ul class="nav navbar-nav">
            	 
              <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li><a href="<?php echo e(route('createpost')); ?>">Create New Post</a></li>
             </ul>

             <ul class="nav navbar-nav navbar-right">
              <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
            </ul>
          </div>
        </div>
      </nav>

