<?php $__env->startSection('title'); ?>
  Blog | <?php echo e($post->post_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 
  <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8" style="padding-bottom: 83px;">

          <!-- Title -->
          <h1 class="mt-4"><?php echo e($post->post_title); ?></h1>

          <!-- Author -->
          <p class="lead">
            by
            <?php echo e($post->user->fullname); ?>

          </p>

          <hr>

          <!-- Date/Time -->
          <p>Posted on <?php echo e($post->created_at); ?></p>

          <hr>

          <!-- Preview Image -->
          <img class="img-fluid rounded" src="<?php echo e(asset('/public/images/'. $post->post_image)); ?>" alt="<?php echo e($post->post_title); ?>">

          <hr>

          <!-- Post Content -->
          <p class="lead"><?php echo e($post->description); ?></p>

          <hr>

          <div>
            <a href="#" class="like" data-postid="<?php echo e($post->id); ?>"><?php echo e(Auth::user()->likes()->where('post_id', $post->id)->first() ? Auth::user()->likes()->where('post_id', $post->id)->first()->like == 1 ? 'Liked' : 'Liked' : 'Like'); ?></a> | <a href="#" id="comment">Comment</a>  
          </div>
          <div id="postRequestData"></div>
          <!-- Comments Form -->
          <div class="comment-box">
            
          <div class="card my-4">
            <h5 class="card-header">Leave a Comment:</h5>
            <div class="card-body">
              <form id="sendcomment" method="post">
                <div class="form-group">
                  <textarea class="form-control" id="comt" name="comment"  rows="3" ></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
           
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- Single Comment -->
            <div class=" comment-area">
              <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
              <div class="media-body">
                <h5 class="mt-0" style="text-transform: capitalize;"><?php echo e($comment->user->fullname); ?></h5>
                <?php echo e($comment->comment); ?>

              </div>
            </div>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div><!-- comment-box -->
          
          
        </div>

       <div class="col-md-4" style="margin-top: 30px;">

            <div class="panel panel-primary">
              <div class="panel-heading">
			    <h3 class="panel-title">Search</h3>
			  </div>
			  <div class="panel-body">
			    <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
              </div>
			  </div>
		    </div>

			<div class="panel panel-success">
			  <div class="panel-heading">
			    <h3 class="panel-title">Categories</h3>
			  </div>
			  <div class="panel-body">
			    Panel content
			  </div>
			</div>

			<div class="panel panel-warning">
			  <div class="panel-heading">
			    <h3 class="panel-title">Side Widget</h3>
			  </div>
			  <div class="panel-body">
			    Panel content
			  </div>
			</div>

        </div>

  </div>
   <script>
     var token = '<?php echo e(Session::token()); ?>';
     var urlLike = '<?php echo e(route('like')); ?>';
     var urlcomment = '<?php echo e(route('comment', ['post_id' => $post->id])); ?>'
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>