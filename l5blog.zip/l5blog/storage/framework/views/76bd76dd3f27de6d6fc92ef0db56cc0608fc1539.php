<nav class="navbar-inverse">
         <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">LOGO</a>
          </div>
           <div id="navbar">
             <ul class="nav navbar-nav">
            	 
              <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
              <li><a href="#">Blog</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Contact Us</a></li>
             </ul>

             <ul class="nav navbar-nav navbar-right">

              <?php if(Auth::user()): ?>

              <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>

              <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><?php echo e(Auth::user()->fullname); ?><span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                </ul>
              </li>

              <?php elseif(!Auth::user()): ?>
                  
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Account <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <form action="<?php echo e(route('login')); ?>" method="post" class="login-tab">
                    <li class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                      <label class="control-label sr-only" for="email">Email</label>
                      <input type="email" name="email" class="form-control input-sm" id="email" placeholder="Email">
                    </li>
                    <li class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                      <label class="control-label sr-only" for="password">password</label>
                      <input type="password" name="password" class="form-control input-sm" id="password" placeholder="Password">
                    </li>
                    <button type="submit"  class="btn btn-primary btn-sm" >Login</button>
                     <a href="<?php echo e(route('account')); ?>" class="btn btn-link newuserlink">create account</a>

                     <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">

                  </form>

                </ul>
              </li>

              <?php else: ?>

              <?php endif; ?>
                
              

            </ul>
          </div>
        </div>
      </nav>

