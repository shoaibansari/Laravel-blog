<?php $__env->startSection('title'); ?>
   Edit Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   <div class="row newpostform">
  	<div class="col-lg-8 col-md-7 col-sm-6">
  	  <div class="well">
  		<form class="form-horizontal" action="<?php echo e(route('post-edit', ['postId' => $post->id])); ?>" method="post" enctype="multipart/form-data" data-editPostId="<?php echo e($post->id); ?>">
  			<fieldset>
  				<legend>Edit Post</legend>
                 

                <div class="form-group">
                    <label for="post-tiltle" class="col-lg-2 control-label">Post Title</label>
                    <div class="col-lg-10">
                      <input type="text" name="post_title" class="form-control input-sm" value="<?php echo e($post->post_title); ?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-tiltle" class="col-lg-2 control-label">Post Slug</label>
                    <div class="col-lg-10">
                      <input type="text" name="slug" class="form-control input-sm" value="<?php echo e($post->slug); ?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="description_title" class="col-lg-2 control-label">Description</label>
                    <div class="col-lg-10">
                      <textarea class="form-control input-sm" name="description" rows="5"><?php echo e($post->description); ?></textarea>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-image" class="col-lg-2 control-label">Post Image</label>
                    <div class="col-lg-10">
                      <img src="<?php echo e(asset('public/images/'. $post->post_image)); ?>" name="post_image" class="img-thumbnail" width="250">
                       <br><br>
                      <input type="file" name="post_image">
                    </div>                
                  </div>
                  <br>
                  <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                      <button type="reset" class="btn btn-default">Cancel</button>
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </div>
                  
  			</fieldset>
  			<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>" >
  		</form>	
  	  </div>
  	</div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>