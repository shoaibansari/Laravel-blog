<?php $__env->startSection('title'); ?>
  Blog | All Tags
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <duiv class="row">
     	<div class="col-md-8">
     		<h2>Tags</h2>
     		<table class="table table-striped">
     			<thead class="tablehead">
     				<tr>
     					<th>#</th>
     				    <th>Name</th>
                
     				</tr>
     			</thead>
     			<tbody>
            <?php $i = 0; ?> 
     				<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	     				<tr>
	     					<th><?php echo e($i += 1); ?></th>
	     					<td><a href="<?php echo e(route('tags.show', $tag->slug)); ?>"><?php echo e($tag->name); ?></a></td>
                
	     				</tr>
     				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     			</tbody>
     		</table>
     	</div> 
        
        <div class="col-md-3" style="margin-top: 30px;">
          <div class="well">
          	<h4>New Tag</h4>
           	<form method="post" action="<?php echo e(route('tags.store')); ?>">
           	   <div class="form-group">
           	   	 <label>Name</label>
           	   	 <input type="text" name="name" class="form-control input-sm">  
           	   </div>

           	   <div class="form-group">
                 <button type="submit" class="btn btn-primary btn-block btn-xs">Create New Tag</button>
               </div>
           	   <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">  
           	</form>
          </div>
        </div>

     </duiv>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>