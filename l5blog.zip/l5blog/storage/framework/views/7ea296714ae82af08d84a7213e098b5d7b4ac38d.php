<?php $__env->startSection('title'); ?>
  User Register !
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 <?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row user-registerfrom">
   	  <div class="col-md-12">
   	  	 <h3 class="signup-heading">Sign Up</h3>
                    <form action="<?php echo e(route('signup')); ?>" method="post" class="form-horizontal" >

                      <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="name" class="col-md-4 control-label">Email</label>
                         <div class="col-md-6">
                            <input type="email" name="email" class="form-control" id="email" value="<?php echo e(Request::old('email')); ?>">
                         </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('fullname') ? ' has-error' : ''); ?>">
                          <label for="email" class="col-md-4 control-label">Full Name</label>
                           <div class="col-md-6">
                              <input type="text" name="fullname" class="form-control" id="fullname" value="<?php echo e(Request::old('fullname')); ?>">
                           </div>
                        </div>

                       <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-md-4 control-label">Password</label>
                         <div class="col-md-6">
                           <input type="password" name="password" class="form-control" id="password" value="<?php echo e(Request::old('password')); ?>">
                         </div>
                       </div>
                        <input type="hidden" name="role_id" value="1">
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Register
                                </button>
                            </div>
                        </div>
                        <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                    </form>
                </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>