<?php $__env->startSection('title'); ?>
  Blog | <?php echo e($post->post_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
 
  <div class="row">

        <!-- Post Content Column -->
        <div class="col-lg-8" style="padding-bottom: 83px;">

          <!-- Title -->
          <h1 class="mt-4" style="text-transform: capitalize;"><?php echo e($post->post_title); ?></h1>

          <hr>

          <!-- Date/Time -->
          <p class="comment-time">Posted on <?php echo e(date('M j D, Y - g:i A',strtotime($post->created_at))); ?> by <a href="#"><?php echo e($post->user->fullname); ?></a></p>

          <hr>

          <!-- Preview Image -->
          <img class="img-fluid rounded" src="<?php echo e(asset('/public/images/'. $post->post_image)); ?>" alt="<?php echo e($post->post_title); ?>">

          <hr>

          <!-- Post Content -->
          <p class="lead" style="padding-left: 0px;"><?php echo e($post->description); ?></p>

          <hr>
          
          <div>
             
            <?php if(Auth::check()): ?>
               
               <a href="#" class="like" data-postid="<?php echo e($post->id); ?>"><?php echo e(Auth::user()->likes()->where('post_id', $post->id)->first() ? Auth::user()->likes()->where('post_id', $post->id)->first()->like == 1 ? 'Liked' : 'Like' : 'Like'); ?></a> | <a href="#" id="comment">Comment</a>

              <?php elseif(Auth::guest() > 0): ?>
                
                 <a href="#" id="guest-like" style="padding-right: 0px !important;">Like</a>
                <?php if(count($post->likes)): ?>
                  <small style="color: #777;font-size: 10px;"><?php echo e($post->likes()->count()); ?></small>
                <?php endif; ?>
               | <a href="#" id="comment">Comment</a>               
              <?php else: ?>

            <?php endif; ?>
            

            <?php if(count($post->comments) > 0): ?>
             <h6 style="float: right;font-weight: 100;color: #777;">Comments <small><?php echo e($post->comments()->count()); ?> total</small></h6> 
            <?php endif; ?>
            

          </div>
          <div id="postRequestData"></div>
          <!-- Comments Form -->
          <div class="comment-box">
            
          <div class="card my-4">
            <h5 class="card-header">Leave a Comment:</h5>
            <div class="card-body">
              <form id="sendcomment" method="post">
                <div class="form-group">
                  <textarea class="form-control" id="comt" name="comment"  rows="3" style="resize: none;"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
             
            <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- Single Comment -->
            <div class="comment-area" >
              <img class="d-flex mr-3 rounded-circle" src="http://placehold.it/50x50" alt="">
              <div class="media-body">
                <h5 class="mt-0" style="text-transform: capitalize;"><?php echo e($comment->user->fullname); ?></h5>
                
                <p id="newcomt"><?php echo e($comment->comment); ?></p>
              </div>
            </div>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div><!-- comment-box -->
          
          
        </div>

       <div class="col-md-4" style="margin-top: 30px;">

            <div class="panel panel-primary">
              <div class="panel-heading">
			    <h3 class="panel-title">Search</h3>
			  </div>
			  <div class="panel-body">
			    <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
              </div>
			  </div>
		    </div>

			<div class="panel panel-success">
			  <div class="panel-heading">
			    <h3 class="panel-title">Post Category</h3>
			  </div>
			  <div class="panel-body">
         <?php echo $cats; ?>

			  </div>
			</div>

     <?php if(count($post->tags) > 0): ?>

  			<div class="panel panel-warning">
  			  <div class="panel-heading">
  			    <h3 class="panel-title">Post Tag</h3>
  			  </div>
  			  <div class="panel-body">
  			    <?php echo implode(' ',$tags); ?>

  			  </div>
  			</div>

        <?php elseif(!count($post->tags)): ?> 
          <div></div>
        <?php else: ?>

      <?php endif; ?>

    

        </div>

  </div>
  
  <?php echo $__env->make('blog.guest-login-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


   <script>
     var token = '<?php echo e(Session::token()); ?>';
     var urlLike = '<?php echo e(route('like')); ?>';
     var urlcomment = '<?php echo e(route('comment', ['postId' => $post->id])); ?>';
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>