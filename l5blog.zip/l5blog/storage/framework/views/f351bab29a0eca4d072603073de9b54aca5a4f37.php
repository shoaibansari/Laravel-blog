<?php $__env->startSection('title'); ?>
  Blog | <?php echo e($tag->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
   <div class="row">
   	  <h2 class="mt-4"><?php echo e($tag->name); ?> <small><?php echo e($tag->posts()->count()); ?> Posts</small></h2>
   	  <hr>

   	  <?php $__currentLoopData = $tag->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   	     
   	  <div class="col-sm-6 contpost">
    <div class="row">
      <div class="col PostTitle">
        <h4 style="text-transform: capitalize;"><a href="<?php echo e(url('blog/'.$tpost->slug)); ?>"><?php echo e($tpost->post_title); ?></a></h4>
        <div class="PostDate"><i class="fa fa-calendar"></i> 
          <?php echo e(date('M j, Y',strtotime($tpost->created_at))); ?></div>

      </div>
    </div>
    
    <div class="row">
      <div class="col-sm-6 feature-img">
        <a href="<?php echo e(url('blog/'.$tpost->slug)); ?>" class="img-responsive">
            <img src="<?php echo e(asset('/public/images/'. $tpost->post_image)); ?>" alt="<?php echo e($tpost->post_title); ?>" width="260" height="180">
        </a>
      </div>
      <div class="col-sm-6" style="padding-left: 0;">      
        <p>
          <?php echo e(str_limit($tpost->description, 100)); ?>

        </p>
        <p><a class="btn btn-sm btn-success" href="<?php echo e(url('blog/'.$tpost->slug)); ?>">Read More</a></p>
      </div>
    </div>
    <div class="row">
      <div class="col text-center small p-2">
        <p style="float: left;padding-left: 15px;">
          <i class="fa fa-user-circle" style="color: #777;"></i> by <a href="#"><?php echo e($tpost->user->fullname); ?></a> 
        
          <?php if(count($tpost->comments) > 0): ?>

          | <a><i class="fa fa-comment"></i> <?php echo e($tpost->comments()->count()); ?><a>
              
          <?php endif; ?>

          <?php if(count($tpost->likes) > 0): ?>

           | <a><i class="fa fa-thumbs-up"></i> <?php echo e($tpost->likes()->count()); ?><a>

          <?php endif; ?>

          | <i class="fa fa-tags" style="color: #777;"></i> Tags : <?php $__currentLoopData = $tpost->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(url('blog/tag/'.$tag->slug)); ?>" class="label label-default" ><?php echo e($tag->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
     
        </p>
      </div>
    </div> 
   </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>