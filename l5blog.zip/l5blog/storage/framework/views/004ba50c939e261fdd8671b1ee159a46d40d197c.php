<?php $__env->startSection('title'); ?>
   Admin dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <h1>Dashboard</h1>
  <h6>Hello <?php echo e(Auth::user()->fullname); ?> !!</h6>
<div class="row newpostform">
	     
	     <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <?php if(Auth::user() == $post->user): ?>  
	      
         <div class="col-lg-4 col-md-7 col-sm-6" data-postid="<?php echo e($post->id); ?>">
	    <div class="panel panel-default">
		  	<a href="<?php echo e(url('blog/'.$post->slug)); ?>"><img src="<?php echo e(asset('public/images/'. $post->post_image)); ?>" class="img-responsive"></a>
		  	<div class="panel-body">
		  	  <ul>
		  		<li><a href="<?php echo e(url('blog/'.$post->slug)); ?>/<?php echo e($post->id); ?>" class="btn btn-info btn-xs">Preview</a></li>
		  		<li><a href="<?php echo e(route('editpost', ['postId' => $post->id])); ?>" class="btn btn-default btn-xs">Edit</a></li>
		  		<li><a href="<?php echo e(route('post.delete', ['post_id' => $post->id])); ?>" class="btn btn-danger btn-xs">Delete</a></li>
		  	  </ul>
		  	</div>
			<div class="panel-heading"><?php echo e($post->post_title); ?></div>
			<div class="panel-body"><?php echo e($post->description); ?></div>
		  </div>  
    </div>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    

	
  	
   
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>