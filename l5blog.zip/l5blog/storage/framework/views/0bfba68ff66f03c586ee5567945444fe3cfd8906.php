<?php $__env->startSection('title'); ?>
   Create Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="row newpostform">
  	<div class="col-lg-8 col-md-7 col-sm-6">
  	  <div class="well">
  		<form class="form-horizontal" action="<?php echo e(route('postsave')); ?>" method="post" enctype="multipart/form-data">
  			<fieldset>
  				<legend>Create New Post</legend>
                 

                <div class="form-group">
                    <label for="post-tiltle" class="col-lg-2 control-label">Post Title</label>
                    <div class="col-lg-10">
                      <input type="text" name="post_title" class="form-control" placeholder="Title" value="<?php echo e(Request::old('post_title')); ?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-slug" class="col-lg-2 control-label">Post Slug</label>
                    <div class="col-lg-10">
                      <input type="text" name="slug" class="form-control" placeholder="Slug" value="<?php echo e(Request::old('slug')); ?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="category_id" class="col-lg-2 control-label">Post Category</label>
                    <div class="col-lg-10">
                      <select class="form-control" name="category">
                        <option></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>


                  <div class="form-group">
                    <label for="tags" class="col-lg-2 control-label">Post Tags</label>
                    <div class="col-lg-10">
                      <select class="form-control select2-multi" name="tags[]" multiple="multiple">
                        <option></option>
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post_description" class="col-lg-2 control-label">Description</label>
                    <div class="col-lg-10">
                      <textarea class="form-control" name="description" rows="5"></textarea>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="post-image" class="col-lg-2 control-label">Post Image</label>
                    <div class="col-lg-10">
                      <input type="file" name="post_image">
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                      <button type="reset" class="btn btn-default btn-sm">Cancel</button>
                      <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                    </div>
                  </div>
                  
  			</fieldset>
  			<input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>" >
  		</form>	
  	  </div>
  	</div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
   <script type="text/javascript">
     $('.select2-multi').select2();
   </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard-master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>