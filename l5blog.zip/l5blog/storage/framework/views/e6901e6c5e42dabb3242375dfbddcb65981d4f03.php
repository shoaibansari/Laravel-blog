<?php $__env->startSection('title'); ?>
    Blog | Blog !
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('includes.message-block', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <h1>Blog</h1>
    <hr>
    <div class="row">

        
        <div class="col-lg-9" style="padding-bottom: 83px;">

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <h3 style="text-transform: capitalize;font-weight: 100;font-size: medium;"><?php echo e($post->post_title); ?></h3>

                <div class="row">
                    <div class="col-md-4">
                        <a href="<?php echo e(url('blog/'.$post->slug)); ?>">
                            <img class="post-thumb" src="<?php echo e(asset('/public/images/'. $post->post_image)); ?>" alt="<?php echo e($post->post_title); ?>">
                        </a>
                    </div><!-- col-md-3 -->

                    <div class="col-md-8" style="padding-left: 0;">
                        <small class="post-date" style="margin: 0 0 10px;">Posted on: <?php echo e(date('M-j-Y',strtotime($post->created_at))); ?> | Category: <strong><?php echo e($post->category->name); ?></strong></small>
                           <p style="margin: 0 0 5px;"><?php echo e(str_limit($post->description, 200)); ?></p>

                        <div class="row">
                            <div class="col text-center small p-2">
                                <p style="float: left;padding-left: 15px;">
                                    <?php if(count($post->comments) > 0): ?>
                                        <a><i class="fa fa-comment"></i> <?php echo e($post->comments()->count()); ?></a>
                                    <?php endif; ?>
                                    <?php if(count($post->likes) > 0): ?>
                                       |  <a><i class="fa fa-thumbs-up"></i> <?php echo e($post->likes()->count()); ?><a>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                        <p><a class="btn btn-default btn-sm" href="<?php echo e(url('blog/'.$post->slug)); ?>">Read More</a></p>

                    </div><!-- col-md-9 -->

                </div><!-- row -->

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="row">
                    <div style="text-align: center;">
                        <?php echo e($posts->links()); ?>

                    </div>
                </div>
        </div>

        
        <div class="col-md-3" style="margin-top: 30px;">

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Search</h3>
                </div>
                <div class="panel-body">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                  <button class="btn btn-secondary" type="button">Go!</button>
                </span>
                    </div>
                </div>
            </div>

            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Categories</h3>
                </div>
                <div class="panel-body">

                   <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count( $category->posts ) > 0): ?>
                            <a href="<?php echo e(url('blog/category/'.$category->slug)); ?>" class="btn btn-default btn-xs"><?php echo e($category->name); ?></a>
                        <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

            

                <div class="panel panel-warning">
                    <div class="panel-heading">
                        <h3 class="panel-title">Tags</h3>
                    </div>
                    <div class="panel-body">
                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if(count($tag->posts ) > 0): ?>
                              <a href="<?php echo e(url('blog/tag/'.$tag->slug)); ?>" class="label label-default"><?php echo e($tag->name); ?></a>
                           <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            
                
            

            


        </div> 

    </div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>