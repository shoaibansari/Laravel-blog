<?php $__env->startSection('title'); ?>
  Blog | <?php echo e($cat->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   
   <div class="row">
   	  <h2 class="mt-4"><?php echo e($cat->name); ?> <small><?php echo e($cat->posts()->count()); ?> Posts</small></h2>
   	  <hr>

   	  <?php $__currentLoopData = $cat->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   	     
   	  <div class="col-sm-6 contpost">
        <div class="row">
          <div class="col PostTitle">
             <h4 style="text-transform: capitalize;"><a href="<?php echo e(url('blog/'.$cpost->slug)); ?>"><?php echo e($cpost->post_title); ?></a></h4>
            <div class="PostDate"><i class="fa fa-calendar"></i>
              <?php echo e(date('M j, Y',strtotime($cpost->created_at))); ?></div>

          </div>
        </div>
    <div class="row">
      <div class="col-sm-6 feature-img">
        <a href="<?php echo e(url('blog/'.$cpost->slug)); ?>" class="img-responsive">
            <img src="<?php echo e(asset('/public/images/'. $cpost->post_image)); ?>" alt="<?php echo e($cpost->post_title); ?>" width="260" height="180">
        </a>
      </div>
      <div class="col-sm-6" style="padding-left: 0;">      
        <p>
          <?php echo e(str_limit($cpost->description, 100)); ?>

        </p>
        <p><a class="btn btn-sm btn-success" href="<?php echo e(url('blog/'.$cpost->slug)); ?>">Read More</a></p>
      </div>
    </div>
    <div class="row">
      <div class="col text-center small p-2">
        <p style="float: left;padding-left: 15px;">
          <i class="fa fa-user-circle"></i> by <a href="#"><?php echo e($cpost->user->fullname); ?></a> 
        
          <?php if(count($cpost->comments) > 0): ?>

          | <a><i class="fa fa-comment"></i> <?php echo e($cpost->comments()->count()); ?></a>
              
          <?php endif; ?>

          <?php if(count($cpost->likes) > 0): ?>

           | <a><i class="fa fa-thumbs-up"></i> <?php echo e($cpost->likes()->count()); ?><a>

          <?php endif; ?>

          
          | <i class="fa fa-tag"></i> Category : 
          
          <a href="<?php echo e(url('blog/category/'.$cpost->category->slug)); ?>" class="label label-default"><?php echo e($cpost->category->name); ?></a>
          
        </p>
      </div>
    </div> 
   </div>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       <div style="text-align: center;">
           
       </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>